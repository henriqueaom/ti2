package auto_estacio;



public class Veiculo2 {

    private String placa;
    private String tipoVeiculo;
   

    // Construtor
    public Veiculo2(String placa, String tipoVeiculo) {
        this.placa = placa;
        this.tipoVeiculo = tipoVeiculo;

    }

    // Getters e Setters
    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getTipoVeiculo() {
        return tipoVeiculo;
    }

    public void setTipoVeiculo(String tipoVeiculo) {
        this.tipoVeiculo = tipoVeiculo;
    }

    
}

    

